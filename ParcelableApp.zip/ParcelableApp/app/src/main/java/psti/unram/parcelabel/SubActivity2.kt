package psti.unram.parcelabel

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SubActivity2 : AppCompatActivity() {
    companion object {
        const val EXTRA_STRING = "EXTRA_STRING"
        const val EXTRA_PARCEL = "EXTRA_PARCEL"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub2)

        val tvData : TextView = findViewById(R.id.tvData)

        val strData = intent.getStringExtra(EXTRA_STRING)
        // Note: getParcelableExtra<T>(String) is deprecated in API 33, but fine for now or we can use the newer one if needed.
        // For simplicity and compatibility, keeping it or using the TIRAMISU+ version.
        val obj = intent.getParcelableExtra<Mahasiswa>(EXTRA_PARCEL)

        val text = if (!strData.isNullOrBlank()) {
            strData
        } else if (obj != null) {
            "NIM: ${obj.nim}, Nama: ${obj.nama}"
        } else {
            "Tidak ada data!"
        }

        tvData.text = text
    }
}