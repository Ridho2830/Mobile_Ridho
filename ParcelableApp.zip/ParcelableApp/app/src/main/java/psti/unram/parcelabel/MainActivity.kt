package psti.unram.parcelabel

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btnPindahActivity : Button =
            findViewById(R.id.btnPindahActivity)
        var btnPindahWithData : Button =
            findViewById(R.id.btnPindahWithData)
        var btnSms : Button = findViewById(R.id.btnSms)
        var btnParcelable : Button = findViewById(R.id.btnParcelabale)

        // pindah ke activity tanpa data
        btnPindahActivity.setOnClickListener(this)
        // pindah ke activity dengan data
        btnPindahWithData.setOnClickListener(this)
        btnSms.setOnClickListener(this)
        btnParcelable.setOnClickListener(this)
    }

    override fun onClick(btn: View?) {
        when(btn!!.id) {
            R.id.btnPindahActivity -> {
                val intent = Intent(this, SubActivity1::class.java)
                startActivity(intent)
            }
            R.id.btnPindahWithData -> {
                val intent = Intent(this, SubActivity2::class.java)
                // menambahkan data yang akan dikirim pada intent
                intent.putExtra(SubActivity2.EXTRA_STRING,
                    "Data dari activity main")
                startActivity(intent)
            }
            R.id.btnSms -> {
                val intent = Intent(Intent.ACTION_VIEW,
                    Uri.parse("smsto:08189234728"))
                startActivity(intent)
            }
            R.id.btnParcelabale -> {
                val intent = Intent(this, SubActivity2::class.java)
                intent.putExtra(SubActivity2.EXTRA_PARCEL,
                    Mahasiswa("F1D021021", "Sena"))
                startActivity(intent)
            }
        }
    }
}